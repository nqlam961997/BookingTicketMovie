export const DANG_NHAP = 'DANG_NHAP';
export const DANG_KI = 'DANG_KI';

export const HANDLE_CHANGE_INPUT = 'HANDLE_CHANGE_INPUT';