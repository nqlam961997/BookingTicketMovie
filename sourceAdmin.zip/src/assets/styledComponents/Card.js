import React from "react";

export const Card = ({number}) => <div className="card">{number}</div>;
