export const LAY_DANH_SACH_PHIM = "LAY_DANH_SACH_PHIM";
export const THEM_PHIM_MOI = "THEM_PHIM_MOI";
export const LAY_THONG_TIN_PHIM = "LAY_THONG_TIN_PHIM";
export const CANCLE_UPDATE = "CANCLE_UPDATE";
export const XOA_PHIM = "XOA_PHIM";

export const VALUE_PHIM = "VALUE_PHIM";
