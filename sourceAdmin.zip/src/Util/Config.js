export const DOMAIN = "https://movie0706.cybersoft.edu.vn";
export const USER_LOGIN = "USER_LOGIN";
export const ACCESSTOKEN = "ACCESSTOKEN";
