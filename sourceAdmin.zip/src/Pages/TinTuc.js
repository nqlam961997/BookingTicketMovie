import React from 'react'

export default function TinTuc(props) {
    return (
        <div>
            TinTuc
        </div>
    )
}
