export const MenuItems = [
  {
    title: "PHIM ĐANG CHIẾU",
    path: "/phimdangchieu",
    cName: "dropdown-link",
  },
  {
    title: "PHIM SẮP CHIẾU",
    path: "/phimsapchieu",
    cName: "dropdown-link",
  },
];
