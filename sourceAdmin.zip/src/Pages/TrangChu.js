import React from "react";
// import Carousel from "react-elastic-carousel";
import { Card } from "../assets/styledComponents/Card";

export default function TrangChu(props) {
  return <></>;
}
